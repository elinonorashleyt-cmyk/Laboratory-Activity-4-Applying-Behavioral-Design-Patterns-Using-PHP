<?php
require_once __DIR__ . '/classes.php';

$records = [
    new Student('Juan Dela Cruz', 'BSIT'),
    new Faculty('Maria Santos', 'Information Technology'),
    new Alumni('Pedro Reyes', 2024),
];

echo "CSV Export Visitor\n";
$csvVisitor = new CSVExportVisitor();
foreach ($records as $record) $record->accept($csvVisitor);

echo "\nReport Visitor\n";
$reportVisitor = new ReportVisitor();
foreach ($records as $record) $record->accept($reportVisitor);

echo "\nStatistics Visitor\n";
$statisticsVisitor = new StatisticsVisitor();
foreach ($records as $record) $record->accept($statisticsVisitor);

echo "\nPDF Report Visitor (simulation)\n";
$pdfVisitor = new PDFReportVisitor();
foreach ($records as $record) $record->accept($pdfVisitor);
