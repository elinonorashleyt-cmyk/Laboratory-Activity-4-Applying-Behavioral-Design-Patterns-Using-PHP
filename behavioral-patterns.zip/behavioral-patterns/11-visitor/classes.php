<?php
declare(strict_types=1);

interface Visitor
{
    public function visitStudent(Student $student): void;
    public function visitFaculty(Faculty $faculty): void;
    public function visitAlumni(Alumni $alumni): void;
}
interface Element
{
    public function accept(Visitor $visitor): void;
    public function getName(): string;
}

class Student implements Element
{
    public function __construct(private string $name, private string $program) {}
    public function getName(): string { return $this->name; }
    public function getProgram(): string { return $this->program; }
    public function accept(Visitor $visitor): void { $visitor->visitStudent($this); }
}
class Faculty implements Element
{
    public function __construct(private string $name, private string $department) {}
    public function getName(): string { return $this->name; }
    public function getDepartment(): string { return $this->department; }
    public function accept(Visitor $visitor): void { $visitor->visitFaculty($this); }
}
class Alumni implements Element
{
    public function __construct(private string $name, private int $graduationYear) {}
    public function getName(): string { return $this->name; }
    public function getGraduationYear(): int { return $this->graduationYear; }
    public function accept(Visitor $visitor): void { $visitor->visitAlumni($this); }
}

class CSVExportVisitor implements Visitor
{
    public function visitStudent(Student $student): void { echo "Student exported: {$student->getName()},{$student->getProgram()}\n"; }
    public function visitFaculty(Faculty $faculty): void { echo "Faculty exported: {$faculty->getName()},{$faculty->getDepartment()}\n"; }
    public function visitAlumni(Alumni $alumni): void { echo "Alumni exported: {$alumni->getName()},{$alumni->getGraduationYear()}\n"; }
}
class ReportVisitor implements Visitor
{
    public function visitStudent(Student $student): void { echo "Student report: {$student->getName()} - {$student->getProgram()}\n"; }
    public function visitFaculty(Faculty $faculty): void { echo "Faculty report: {$faculty->getName()} - {$faculty->getDepartment()}\n"; }
    public function visitAlumni(Alumni $alumni): void { echo "Alumni report: {$alumni->getName()} - Class of {$alumni->getGraduationYear()}\n"; }
}
class StatisticsVisitor implements Visitor
{
    public function visitStudent(Student $student): void { echo "Student record counted: {$student->getName()}\n"; }
    public function visitFaculty(Faculty $faculty): void { echo "Faculty record counted: {$faculty->getName()}\n"; }
    public function visitAlumni(Alumni $alumni): void { echo "Alumni record counted: {$alumni->getName()}\n"; }
}
class PDFReportVisitor implements Visitor
{
    public function visitStudent(Student $student): void { echo "[PDF report simulation] Student: {$student->getName()} ({$student->getProgram()})\n"; }
    public function visitFaculty(Faculty $faculty): void { echo "[PDF report simulation] Faculty: {$faculty->getName()} ({$faculty->getDepartment()})\n"; }
    public function visitAlumni(Alumni $alumni): void { echo "[PDF report simulation] Alumni: {$alumni->getName()} (Class of {$alumni->getGraduationYear()})\n"; }
}
