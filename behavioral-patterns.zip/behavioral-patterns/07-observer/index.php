<?php
require_once __DIR__ . '/classes.php';

$gradeSystem = new GradeSystem();
$gradeSystem->attach(new StudentPortal());
$gradeSystem->attach(new EmailNotification());
$gradeSystem->attach(new ParentNotification());

$gradeSystem->updateGrade(1.75);
