<?php
declare(strict_types=1);

interface Observer
{
    public function update(float $grade): void;
}

class GradeSystem
{
    /** @var Observer[] */
    private array $observers = [];

    public function attach(Observer $observer): void { $this->observers[] = $observer; }
    public function detach(Observer $observer): void
    {
        $this->observers = array_values(array_filter($this->observers, fn($item) => $item !== $observer));
    }
    public function updateGrade(float $grade): void
    {
        echo "Grade updated: " . number_format($grade, 2) . "\n";
        foreach ($this->observers as $observer) $observer->update($grade);
    }
}

class StudentPortal implements Observer
{
    public function update(float $grade): void { echo "Student Portal:\nNew grade posted: " . number_format($grade, 2) . "\n\n"; }
}
class EmailNotification implements Observer
{
    public function update(float $grade): void { echo "Email Notification:\nYour grade has been updated to " . number_format($grade, 2) . ".\n\n"; }
}
class ParentNotification implements Observer
{
    public function update(float $grade): void { echo "Parent Notification:\nStudent grade " . number_format($grade, 2) . " has been posted.\n\n"; }
}
