<?php
require_once __DIR__ . '/classes.php';

$student = new StudentContext(['program' => 'BSIT', 'year' => 4, 'name' => 'Juan']);
$bsit = new TerminalExpression('PROGRAM', '=', 'BSIT');
$fourthYear = new TerminalExpression('YEAR', '=', 4);
$expression = new AndExpression($bsit, $fourthYear);

echo "Expression:\nPROGRAM = \"BSIT\" AND YEAR = 4\n";
echo "Result: " . ($expression->interpret($student) ? 'TRUE' : 'FALSE') . "\n\n";

$bsitOrBscs = new OrExpression(
    new TerminalExpression('PROGRAM', '=', 'BSIT'),
    new TerminalExpression('PROGRAM', '=', 'BSCS')
);
echo "Expression:\nPROGRAM = \"BSIT\" OR PROGRAM = \"BSCS\"\n";
echo "Result: " . ($bsitOrBscs->interpret($student) ? 'TRUE' : 'FALSE') . "\n";
