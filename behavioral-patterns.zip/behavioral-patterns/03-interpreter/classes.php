<?php
declare(strict_types=1);

class StudentContext
{
    public function __construct(private array $student) {}
    public function get(string $key): mixed { return $this->student[strtolower($key)] ?? null; }
}

interface Expression
{
    public function interpret(StudentContext $context): bool;
}

class TerminalExpression implements Expression
{
    public function __construct(private string $field, private string $operator, private string|int $value) {}

    public function interpret(StudentContext $context): bool
    {
        $actual = $context->get($this->field);
        if ($actual === null) return false;

        return match ($this->operator) {
            '=' , '==' => (string)$actual === (string)$this->value,
            '!=' => (string)$actual !== (string)$this->value,
            '>' => is_numeric($actual) && is_numeric($this->value) && $actual > $this->value,
            '<' => is_numeric($actual) && is_numeric($this->value) && $actual < $this->value,
            default => false,
        };
    }
}

class AndExpression implements Expression
{
    public function __construct(private Expression $left, private Expression $right) {}
    public function interpret(StudentContext $context): bool
    {
        return $this->left->interpret($context) && $this->right->interpret($context);
    }
}
class OrExpression implements Expression
{
    public function __construct(private Expression $left, private Expression $right) {}
    public function interpret(StudentContext $context): bool
    {
        return $this->left->interpret($context) || $this->right->interpret($context);
    }
}
