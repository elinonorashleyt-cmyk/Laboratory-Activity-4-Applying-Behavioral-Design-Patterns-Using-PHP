<?php
require_once __DIR__ . '/classes.php';

$profile = new StudentProfile('Juan Dela Cruz', 'BSIT', 3, 'juan@example.com');
$history = new ProfileHistory();
$history->save($profile);
$profile->display("Original Profile:");

$profile->update('BSCS', 4);
$profile->display("Current Profile:");

echo "Undo...\n\n";
$history->undo($profile);
$profile->display("Restored Profile:");
