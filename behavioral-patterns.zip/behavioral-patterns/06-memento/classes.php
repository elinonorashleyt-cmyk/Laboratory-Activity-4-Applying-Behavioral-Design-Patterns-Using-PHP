<?php
declare(strict_types=1);

class StudentProfileMemento
{
    public function __construct(
        public readonly string $name,
        public readonly string $program,
        public readonly int $year,
        public readonly string $email
    ) {}
}

class StudentProfile
{
    public function __construct(
        private string $name,
        private string $program,
        private int $year,
        private string $email
    ) {}

    public function save(): StudentProfileMemento
    {
        return new StudentProfileMemento($this->name, $this->program, $this->year, $this->email);
    }

    public function restore(StudentProfileMemento $memento): void
    {
        $this->name = $memento->name;
        $this->program = $memento->program;
        $this->year = $memento->year;
        $this->email = $memento->email;
    }

    public function update(string $program, int $year): void
    {
        $this->program = $program;
        $this->year = $year;
    }

    public function display(string $heading): void
    {
        echo $heading . "\n";
        echo "Name: {$this->name}\nProgram: {$this->program}\nYear: {$this->year}\nEmail: {$this->email}\n\n";
    }
}

class ProfileHistory
{
    private array $history = [];
    public function save(StudentProfile $profile): void { $this->history[] = $profile->save(); }
    public function undo(StudentProfile $profile): void
    {
        $memento = array_pop($this->history);
        if ($memento) $profile->restore($memento);
    }
}
