<?php
declare(strict_types=1);

abstract class Report
{
    final public function generateReport(): void
    {
        $this->header();
        $this->retrieveData();
        $this->formatData();
        $this->footer();
    }

    protected function header(): void
    {
        echo "========================\n" . strtoupper($this->title()) . "\n========================\n";
    }
    protected function footer(): void { echo "========================\nEND OF REPORT\n========================\n"; }
    abstract protected function title(): string;
    abstract protected function retrieveData(): void;
    abstract protected function formatData(): void;
}

class StudentReport extends Report
{
    protected function title(): string { return 'Student Report'; }
    protected function retrieveData(): void { echo "Student data retrieved.\n"; }
    protected function formatData(): void
    {
        echo "Student ID: 2026-001\nName: Juan Dela Cruz\nProgram: BSIT\n";
    }
}
class GradeReport extends Report
{
    protected function title(): string { return 'Grade Report'; }
    protected function retrieveData(): void { echo "Grade data retrieved.\n"; }
    protected function formatData(): void { echo "Student: Juan Dela Cruz\nSubject: OOP\nGrade: 1.75\n"; }
}
class EnrollmentReport extends Report
{
    protected function title(): string { return 'Enrollment Report'; }
    protected function retrieveData(): void { echo "Enrollment data retrieved.\n"; }
    protected function formatData(): void { echo "Student ID: 2026-001\nStatus: Enrolled\nSemester: First Semester\n"; }
}
