<?php
require_once __DIR__ . '/classes.php';

echo "STUDENT REPORT DEMO\n";
(new StudentReport())->generateReport();

echo "\nGRADE REPORT DEMO\n";
(new GradeReport())->generateReport();

echo "\nENROLLMENT REPORT DEMO\n";
(new EnrollmentReport())->generateReport();
