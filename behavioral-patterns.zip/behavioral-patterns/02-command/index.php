<?php
require_once __DIR__ . '/classes.php';

$system = new StudentSystem();
$invoker = new CommandInvoker();

$invoker->run(new EnrollCommand($system));
$invoker->run(new DropSubjectCommand($system));
$invoker->run(new PrintRegistrationCommand($system));
$invoker->undoLast();
