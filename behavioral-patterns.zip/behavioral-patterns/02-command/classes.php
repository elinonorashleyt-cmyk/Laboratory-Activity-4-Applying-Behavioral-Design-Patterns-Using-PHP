<?php
declare(strict_types=1);

interface Command
{
    public function execute(): void;
    public function undo(): void;
    public function getName(): string;
}

class StudentSystem
{
    public bool $enrolled = false;
    public bool $subjectDropped = false;
    public bool $registrationPrinted = false;
    public bool $loggedIn = true;

    public function enroll(): void { $this->enrolled = true; echo "Student successfully enrolled.\n"; }
    public function undoEnroll(): void { $this->enrolled = false; echo "Enrollment undone.\n"; }
    public function dropSubject(): void { $this->subjectDropped = true; echo "Subject successfully dropped.\n"; }
    public function undoDropSubject(): void { $this->subjectDropped = false; echo "Subject drop undone.\n"; }
    public function printRegistration(): void { $this->registrationPrinted = true; echo "Registration form printed.\n"; }
    public function undoPrintRegistration(): void { $this->registrationPrinted = false; echo "Print action undone.\n"; }
    public function logout(): void { $this->loggedIn = false; echo "Student logged out.\n"; }
    public function undoLogout(): void { $this->loggedIn = true; echo "Student logged in again.\n"; }
}

class EnrollCommand implements Command
{
    public function __construct(private StudentSystem $system) {}
    public function execute(): void { $this->system->enroll(); }
    public function undo(): void { $this->system->undoEnroll(); }
    public function getName(): string { return 'Enroll Student'; }
}
class DropSubjectCommand implements Command
{
    public function __construct(private StudentSystem $system) {}
    public function execute(): void { $this->system->dropSubject(); }
    public function undo(): void { $this->system->undoDropSubject(); }
    public function getName(): string { return 'Drop Subject'; }
}
class PrintRegistrationCommand implements Command
{
    public function __construct(private StudentSystem $system) {}
    public function execute(): void { $this->system->printRegistration(); }
    public function undo(): void { $this->system->undoPrintRegistration(); }
    public function getName(): string { return 'Print Registration'; }
}
class LogoutCommand implements Command
{
    public function __construct(private StudentSystem $system) {}
    public function execute(): void { $this->system->logout(); }
    public function undo(): void { $this->system->undoLogout(); }
    public function getName(): string { return 'Logout'; }
}

class CommandInvoker
{
    private array $history = [];

    public function run(Command $command): void
    {
        echo "Executing: " . $command->getName() . "\n";
        $command->execute();
        $this->history[] = $command;
        echo "\n";
    }

    public function undoLast(): void
    {
        $command = array_pop($this->history);
        if ($command === null) {
            echo "Nothing to undo.\n";
            return;
        }
        echo "Undoing: " . $command->getName() . "\n";
        $command->undo();
    }
}
