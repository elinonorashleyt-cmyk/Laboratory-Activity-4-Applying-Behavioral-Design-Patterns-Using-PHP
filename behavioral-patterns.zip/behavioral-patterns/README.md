# Laboratory Activity #4: Applying Behavioral Design Patterns Using PHP

This project demonstrates all 11 Behavioral Design Patterns listed in the activity PDF. Each pattern has its own folder, PHP class/source file, and `index.php` demonstration.

## Requirements
- PHP 8.0 or newer recommended
- No external libraries or database required

## Run a demonstration
Open a terminal in this project folder and run, for example:

```bash
php 01-chain-of-responsibility/index.php
php 02-command/index.php
php 03-interpreter/index.php
php 04-iterator/index.php
php 05-mediator/index.php
php 06-memento/index.php
php 07-observer/index.php
php 08-state/index.php
php 09-strategy/index.php
php 10-template-method/index.php
php 11-visitor/index.php
```

Alternatively, use PHP's built-in server from this folder:

```bash
php -S localhost:8000
```

Then open `http://localhost:8000/01-chain-of-responsibility/` and change the folder name to view another demonstration.

## Four patterns for the required video
The assignment asks you to select four patterns and coordinate with classmates so your selection is different. This project implements all 11; for a clear demonstration, a suggested set is:
1. Chain of Responsibility
2. Command
3. Observer
4. Strategy

Please confirm that these four are not already selected by classmates before recording.

## Video submission checklist from the activity
- Record both your face and your screen throughout the implementation/demo.
- You may use OBS Studio.
- Demonstrate the four selected patterns and explain how the code works.
- At the end, discuss your experience, challenges, and what you learned.
- Upload your recording to YouTube and submit the link through the Google Form in your activity instructions.
- Upload this complete project to your GitHub account and submit the repository link in the form.

I cannot record your face/screen, upload a video to your YouTube account, or publish to your GitHub account from this chat. The code and checklist are prepared so you can do those steps yourself.

## Required reflection questions — sample answers
1. **Which Behavioral Design Pattern was easiest to implement? Explain.**  
   The Iterator pattern was easiest for me because it lets me go through a collection of student records one by one. The code is easy to follow, and I can display each student without directly accessing the collection's internal array.

2. **Which pattern was the most difficult to implement? Explain why.**  
   The Interpreter pattern was the most difficult for me because it needs to read conditions and evaluate them correctly. I had to understand how terminal expressions and combined expressions work together, especially when using AND and OR.

3. **Which Behavioral Design Pattern is most useful in real-world applications? Explain.**  
   I think the Observer pattern is very useful because one change can automatically notify different parts of a system. For example, when a student's grade changes, the student portal, email notification, and parent notification can all be updated without putting all their actions into one class.

Edit these answers so they accurately describe your own experience after implementing and testing the project.
