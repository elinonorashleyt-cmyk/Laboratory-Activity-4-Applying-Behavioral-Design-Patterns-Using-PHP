<?php
require_once __DIR__ . '/classes.php';

$scores = [90, 85, 92];
$calculator = new GradeCalculator(new SimpleAverageStrategy());
echo "Strategy: Simple Average\n";
echo "Result: " . number_format($calculator->calculate($scores), 2) . "\n\n";

$calculator->setStrategy(new WeightedAverageStrategy([0.50, 0.30, 0.20]));
echo "Strategy: Weighted Average\n";
echo "Result: " . number_format($calculator->calculate($scores), 2) . "\n\n";

$calculator->setStrategy(new TransmutedGradeStrategy());
echo "Strategy: Transmuted Grade\n";
echo "Result: " . number_format($calculator->calculate($scores), 2) . "\n";
