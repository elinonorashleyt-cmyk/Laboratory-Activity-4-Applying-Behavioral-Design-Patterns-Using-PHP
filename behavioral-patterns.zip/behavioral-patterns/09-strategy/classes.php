<?php
declare(strict_types=1);

interface GradeStrategy
{
    public function calculate(array $scores): float;
}

class SimpleAverageStrategy implements GradeStrategy
{
    public function calculate(array $scores): float
    {
        if (count($scores) === 0) return 0.0;
        return array_sum($scores) / count($scores);
    }
}
class WeightedAverageStrategy implements GradeStrategy
{
    public function __construct(private array $weights) {}
    public function calculate(array $scores): float
    {
        if (count($scores) !== count($this->weights) || count($scores) === 0) {
            throw new InvalidArgumentException('Scores and weights must have the same non-zero length.');
        }
        if (abs(array_sum($this->weights) - 1.0) > 0.00001) {
            throw new InvalidArgumentException('Weights must add up to 1.0.');
        }
        $total = 0.0;
        foreach ($scores as $index => $score) $total += $score * $this->weights[$index];
        return $total;
    }
}
class TransmutedGradeStrategy implements GradeStrategy
{
    public function calculate(array $scores): float
    {
        $average = (new SimpleAverageStrategy())->calculate($scores);
        // Demonstration-only transmutation formula; institutions may use a different scale.
        return min(100.0, max(0.0, 50.0 + ($average * 0.5)));
    }
}
class GradeCalculator
{
    public function __construct(private GradeStrategy $strategy) {}
    public function setStrategy(GradeStrategy $strategy): void { $this->strategy = $strategy; }
    public function calculate(array $scores): float { return $this->strategy->calculate($scores); }
}
