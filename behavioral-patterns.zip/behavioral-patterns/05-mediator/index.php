<?php
require_once __DIR__ . '/classes.php';

$chat = new ChatMediator();
$juan = new Student('Juan', $chat);
$maria = new Student('Maria', $chat);
$pedro = new Student('Pedro', $chat);

$juan->send('Hello everyone!');
