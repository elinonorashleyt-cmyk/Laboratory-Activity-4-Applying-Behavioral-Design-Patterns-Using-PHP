<?php
require_once __DIR__ . '/classes.php';

$student = new Student(new ApplicantState());
echo "Current State: " . $student->getStateName() . "\nAction: Enroll\n";
$student->enroll();
echo "\nCurrent State: " . $student->getStateName() . "\nAction: Pre-assess\n";
$student->preAssess();
echo "\nCurrent State: " . $student->getStateName() . "\nAction: Enroll\n";
$student->enroll();
echo "\nCurrent State: " . $student->getStateName() . "\nAction: Drop\n";
$student->drop();
echo "\nCurrent State: " . $student->getStateName() . "\n";
