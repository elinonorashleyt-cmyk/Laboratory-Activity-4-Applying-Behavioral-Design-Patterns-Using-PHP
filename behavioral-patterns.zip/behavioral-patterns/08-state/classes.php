<?php
declare(strict_types=1);

interface State
{
    public function name(): string;
    public function enroll(Student $student): void;
    public function preAssess(Student $student): void;
    public function drop(Student $student): void;
    public function graduate(Student $student): void;
}

abstract class BaseState implements State
{
    public function preAssess(Student $student): void { echo "Pre-assessment is not available in " . $this->name() . " state.\n"; }
    public function enroll(Student $student): void { echo "Enrollment is not available in " . $this->name() . " state.\n"; }
    public function drop(Student $student): void { echo "Dropping is not available in " . $this->name() . " state.\n"; }
    public function graduate(Student $student): void { echo "Graduation is not available in " . $this->name() . " state.\n"; }
}
class ApplicantState extends BaseState
{
    public function name(): string { return 'Applicant'; }
    public function preAssess(Student $student): void { echo "Pre-assessment completed.\n"; $student->setState(new PreAssessedState()); }
}
class PreAssessedState extends BaseState
{
    public function name(): string { return 'Pre-Assessed'; }
    public function enroll(Student $student): void { echo "Student successfully enrolled.\n"; $student->setState(new EnrolledState()); }
}
class EnrolledState extends BaseState
{
    public function name(): string { return 'Enrolled'; }
    public function drop(Student $student): void { echo "Student has dropped enrollment.\n"; $student->setState(new DroppedState()); }
}
class DroppedState extends BaseState
{
    public function name(): string { return 'Dropped'; }
    public function graduate(Student $student): void { echo "A dropped student cannot graduate until re-enrolled.\n"; }
}
class GraduatedState extends BaseState
{
    public function name(): string { return 'Graduated'; }
}
class Student
{
    public function __construct(private State $state) {}
    public function setState(State $state): void { $this->state = $state; }
    public function getStateName(): string { return $this->state->name(); }
    public function preAssess(): void { $this->state->preAssess($this); }
    public function enroll(): void { $this->state->enroll($this); }
    public function drop(): void { $this->state->drop($this); }
    public function graduate(): void { $this->state->graduate($this); }
}
