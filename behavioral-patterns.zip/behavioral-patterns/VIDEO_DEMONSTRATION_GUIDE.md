# Video Demonstration Guide (Suggested Four Patterns)

**Before recording:** Check with classmates that these four patterns are not already taken. The activity requires a unique selection.

## Suggested order
1. Chain of Responsibility
2. Command
3. Observer
4. Strategy

## Opening
"Good day. In this video, I will demonstrate four Behavioral Design Patterns using plain PHP. Behavioral patterns describe how objects communicate and share responsibilities. I will show the code, run each example, and explain its output."

## Pattern 1: Chain of Responsibility
"Chain of Responsibility passes a request through a chain of handlers. In this example, a student request goes through Student Affairs, Registrar, Finance, and ICT. Each office checks whether it can process the request. The Transcript of Records request is handled by the Registrar."

Show `01-chain-of-responsibility/classes.php`, then run:
`php 01-chain-of-responsibility/index.php`

## Pattern 2: Command
"The Command pattern represents an action as an object. The invoker runs commands without needing to know the details of each action. Here, the system can enroll a student, drop a subject, print registration, and undo the last command."

Show `02-command/classes.php`, then run:
`php 02-command/index.php`

## Pattern 3: Observer
"The Observer pattern notifies multiple observers when an event happens. When the grade is updated, the student portal, email notification, and parent notification receive the update. We can add another observer by implementing the Observer interface and attaching it, without rewriting GradeSystem."

Show `07-observer/classes.php`, then run:
`php 07-observer/index.php`

## Pattern 4: Strategy
"The Strategy pattern places different algorithms behind one interface. The GradeCalculator can use simple average, weighted average, or transmuted grade. I can change the strategy without changing the GradeCalculator class."

Show `09-strategy/classes.php`, then run:
`php 09-strategy/index.php`

## Closing reflection
"While implementing the patterns, I learned that each pattern solves a different problem in how objects communicate. One challenge was understanding which class should handle each responsibility. Testing the examples helped me see how interfaces, composition, and polymorphism make the code easier to extend. I can use these ideas to keep larger projects organized."

Make sure your final reflection is truthful to your own experience. Keep your face and screen visible for the whole recording, as required by the activity.
