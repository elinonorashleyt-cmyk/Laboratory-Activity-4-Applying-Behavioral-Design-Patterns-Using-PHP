<?php
declare(strict_types=1);

class StudentRequest
{
    public function __construct(public string $type) {}
}

abstract class Handler
{
    protected ?Handler $next = null;

    public function setNext(Handler $handler): Handler
    {
        $this->next = $handler;
        return $handler;
    }

    public function handle(StudentRequest $request): void
    {
        if ($this->canHandle($request)) {
            echo static::class . ': Processing ' . $request->type . "...\n";
            return;
        }

        echo static::class . ": Cannot process request.\n";
        if ($this->next !== null) {
            $this->next->handle($request);
        } else {
            echo "No office could process this request.\n";
        }
    }

    abstract protected function canHandle(StudentRequest $request): bool;
}

class StudentAffairsHandler extends Handler
{
    protected function canHandle(StudentRequest $request): bool
    {
        return in_array($request->type, ['Good Moral Certificate'], true);
    }
}
class RegistrarHandler extends Handler
{
    protected function canHandle(StudentRequest $request): bool
    {
        return in_array($request->type, ['Certificate of Enrollment', 'Transcript of Records'], true);
    }
}
class FinanceHandler extends Handler
{
    protected function canHandle(StudentRequest $request): bool
    {
        return $request->type === 'Payment Concern';
    }
}
class ICTHandler extends Handler
{
    protected function canHandle(StudentRequest $request): bool
    {
        return $request->type === 'Student ID Concern';
    }
}
